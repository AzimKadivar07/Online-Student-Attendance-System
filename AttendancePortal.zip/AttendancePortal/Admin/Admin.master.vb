﻿
Partial Class Admin_Admin
    Inherits System.Web.UI.MasterPage
End Class

